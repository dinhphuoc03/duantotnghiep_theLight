package poly.store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import poly.store.model.Staff;

@Repository
public interface StaffRepository extends JpaRepository<Staff, Integer> {
    // Không cần thêm bất kỳ phương thức nào nếu bạn chỉ sử dụng những phương thức cơ bản
}



