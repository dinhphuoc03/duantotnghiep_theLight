package poly.store.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import poly.store.model.Customer;
import poly.store.repository.CustomerRepository;

@Controller
@RequestMapping("/admin")
public class CustomerController {

    @Autowired
    private CustomerRepository customerRepository;

    // Thay đổi đường dẫn về /admin/customer để khớp với home.html
    @GetMapping("/customer")
    public String showCustomerList(Model model) {
        List<Customer> customers = customerRepository.findAll();
        model.addAttribute("customers", customers);
        model.addAttribute("customer", new Customer());
        return "admin/customer";  // Trả về trang customer.html
    }

    @PostMapping("/customers/save")
    public String saveCustomer(@ModelAttribute("customer") Customer customer) {
        customer.setCreatedAt(LocalDateTime.now());
        customer.setUpdatedAt(LocalDateTime.now());
        customerRepository.save(customer);
        return "redirect:/admin/customer";
    }

    @GetMapping("/customers/edit/{id}")
    public String showEditCustomerForm(@PathVariable("id") Integer id, Model model) {
        Customer customer = customerRepository.findById(id).orElse(null);
        model.addAttribute("customer", customer);
        return "admin/customer-form";  // Trả về trang form chỉnh sửa khách hàng
    }

    @GetMapping("/customers/delete/{id}")
    public String deleteCustomer(@PathVariable("id") Integer id) {
        customerRepository.deleteById(id);
        return "redirect:/admin/customer";
    }
}
