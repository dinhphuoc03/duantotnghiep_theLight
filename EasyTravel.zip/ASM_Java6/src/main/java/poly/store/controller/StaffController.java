package poly.store.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import poly.store.model.Staff;
import poly.store.repository.StaffRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/staff")
public class StaffController {

    @Autowired
    private StaffRepository staffRepository;

    @GetMapping
    public List<Staff> getAllStaff() {
        return staffRepository.findAll();
    }

    @GetMapping("/{id}")
    public Staff getStaffById(@PathVariable Integer id) {
        return staffRepository.findById(id).orElse(null);
    }

    @PostMapping
    public Staff createStaff(@RequestBody Staff staff) {
        staff.setCreatedAt(LocalDateTime.now()); // Thiết lập thời gian tạo
        staff.setUpdatedAt(LocalDateTime.now()); // Thiết lập thời gian cập nhật
        return staffRepository.save(staff);
    }

    @PutMapping("/{id}")
    public Staff updateStaff(@PathVariable Integer id, @RequestBody Staff staffDetails) {
        Staff staff = staffRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy nhân viên với ID: " + id));
        
        staff.setName(staffDetails.getName());
        staff.setEmail(staffDetails.getEmail());
        staff.setPhone(staffDetails.getPhone());
        staff.setRole(staffDetails.getRole());
        staff.setStatus(staffDetails.getStatus()); // Cập nhật trạng thái

        staff.setUpdatedAt(LocalDateTime.now()); // Cập nhật thời gian
        return staffRepository.save(staff);
    }

    @DeleteMapping("/{id}")
    public void deleteStaff(@PathVariable Integer id) {
        staffRepository.deleteById(id);
    }
}



