// Lấy dữ liệu từ API
fetch('/api/hotels')
    .then(response => response.json())
    .then(data => {
        let cardContainer = document.getElementById('card-container'); // ID của div chứa các thẻ card
        cardContainer.innerHTML = ''; // Clear container

        data.forEach(hotel => {
            let cardHTML = `
                <div class="col-md-4">
                    <div class="card">
                        <a href="/html/HotelDetails.html?id=${hotel.hotelId}">
                            <img src="${hotel.imageUrl}" width="410px" height="220px">
                            <span class="badge">Giảm ${hotel.discount}%</span>
                        </a>
                        <div class="card-body">
                            <h5 class="card-title">${hotel.name}</h5>
                            <p class="yacht-info">
                                <i class="fas fa-star text-warning"></i> Đánh giá: ${hotel.rating}
                            </p>
                            <p class="yacht-info">
                                <i class="fas fa-map-marker-alt"></i> ${hotel.address}
                            </p>
                            <p class="original-price">${hotel.originalPrice}đ</p>
                            <p class="discount-text">${hotel.discountPrice}đ</p>
                            <a href="BookingHotel.html?hotelId=${hotel.hotelId}" class="btn btn-primary">Đặt ngay</a>
                        </div>
                    </div>
                </div>
            `;
            cardContainer.innerHTML += cardHTML; // Append từng card
        });
    })
    .catch(error => console.log('Error:', error));
