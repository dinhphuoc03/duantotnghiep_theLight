package com.poly.repository;

import com.poly.model.Tour;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TourRepository extends JpaRepository<Tour, String> {
    
    // Tìm tất cả tour theo nhà cung cấp
    List<Tour> findByProviderId(String providerId);
    
    // Tìm tour theo tên
    List<Tour> findByTourNameContaining(String tourName);
}
