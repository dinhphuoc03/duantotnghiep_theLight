package com.poly.repository;

import com.poly.model.Staff;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface StaffRepository extends JpaRepository<Staff, String> {
    
    // Tìm nhân viên theo email
    Optional<Staff> findByEmail(String email);
    
    // Kiểm tra sự tồn tại của nhân viên theo email
    boolean existsByEmail(String email);
}
