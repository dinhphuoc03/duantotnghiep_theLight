package com.poly.repository;

import com.poly.model.ServiceProvider;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ServiceProviderRepository extends JpaRepository<ServiceProvider, String> {
    
    // Tìm nhà cung cấp dịch vụ theo tên
    Optional<ServiceProvider> findByName(String name);
    
    // Kiểm tra sự tồn tại của nhà cung cấp dịch vụ theo tên
    boolean existsByName(String name);
}
