package com.poly.service;

import com.poly.model.Hotel;
import java.util.List;

public interface HotelService {
    Hotel save(Hotel hotel);
    Hotel findById(String id);
    List<Hotel> findAll();
    void delete(String id);
}
