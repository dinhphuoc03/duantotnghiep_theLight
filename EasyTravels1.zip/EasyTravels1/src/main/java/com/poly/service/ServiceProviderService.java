package com.poly.service;

import com.poly.model.ServiceProvider;
import java.util.List;

public interface ServiceProviderService {
    ServiceProvider save(ServiceProvider serviceProvider);
    ServiceProvider findById(String id);
    List<ServiceProvider> findAll();
    void delete(String id);
}
