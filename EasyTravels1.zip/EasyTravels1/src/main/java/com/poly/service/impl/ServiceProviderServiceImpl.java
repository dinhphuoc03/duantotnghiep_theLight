package com.poly.service.impl;

import com.poly.model.ServiceProvider;
import com.poly.repository.ServiceProviderRepository;
import com.poly.service.ServiceProviderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServiceProviderServiceImpl implements ServiceProviderService {

    @Autowired
    private ServiceProviderRepository serviceProviderRepository;

    @Override
    public ServiceProvider save(ServiceProvider serviceProvider) {
        return serviceProviderRepository.save(serviceProvider);
    }

    @Override
    public ServiceProvider findById(String id) {
        return serviceProviderRepository.findById(id).orElse(null);
    }

    @Override
    public List<ServiceProvider> findAll() {
        return serviceProviderRepository.findAll();
    }

    @Override
    public void delete(String id) {
        serviceProviderRepository.deleteById(id);
    }
}
