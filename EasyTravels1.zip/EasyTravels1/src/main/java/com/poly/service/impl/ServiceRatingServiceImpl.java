package com.poly.service.impl;

import com.poly.model.ServiceRating;
import com.poly.repository.ServiceRatingRepository;
import com.poly.service.ServiceRatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServiceRatingServiceImpl implements ServiceRatingService {

    @Autowired
    private ServiceRatingRepository serviceRatingRepository;

    @Override
    public ServiceRating save(ServiceRating serviceRating) {
        return serviceRatingRepository.save(serviceRating);
    }

    @Override
    public ServiceRating findById(String id) {
        return serviceRatingRepository.findById(id).orElse(null);
    }

    @Override
    public List<ServiceRating> findAll() {
        return serviceRatingRepository.findAll();
    }

    @Override
    public void delete(String id) {
        serviceRatingRepository.deleteById(id);
    }
}
