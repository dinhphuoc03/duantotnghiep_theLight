package com.poly.service;

import com.poly.model.Account;
import java.util.List;

public interface AccountService {
    Account save(Account account);
    Account findById(String id);
    List<Account> findAll();
    void delete(String id);
}
