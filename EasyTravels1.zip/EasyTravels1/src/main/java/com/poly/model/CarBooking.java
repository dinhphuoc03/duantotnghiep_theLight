package com.poly.model;


import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "CarBookings")
public class CarBooking {

    @Id
    @Column(name = "booking_id", length = 10)
    private String bookingId;

    @Column(name = "car_name", nullable = false, length = 100)
    private String carName;

    @Column(name = "pick_up_date", nullable = false)
    private LocalDateTime pickUpDate;

    @Column(name = "drop_off_date", nullable = false)
    private LocalDateTime dropOffDate;

    @Column(name = "total_price", nullable = false)
    private Double totalPrice;

    @Column(name = "status", length = 50)
    private String status;

    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    // Constructors
    public CarBooking() {}

    public CarBooking(String bookingId, String carName, LocalDateTime pickUpDate, LocalDateTime dropOffDate, Double totalPrice, String status, Customer customer) {
        this.bookingId = bookingId;
        this.carName = carName;
        this.pickUpDate = pickUpDate;
        this.dropOffDate = dropOffDate;
        this.totalPrice = totalPrice;
        this.status = status;
        this.customer = customer;
    }

    // Getters and Setters
    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public LocalDateTime getPickUpDate() {
        return pickUpDate;
    }

    public void setPickUpDate(LocalDateTime pickUpDate) {
        this.pickUpDate = pickUpDate;
    }

    public LocalDateTime getDropOffDate() {
        return dropOffDate;
    }

    public void setDropOffDate(LocalDateTime dropOffDate) {
        this.dropOffDate = dropOffDate;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
