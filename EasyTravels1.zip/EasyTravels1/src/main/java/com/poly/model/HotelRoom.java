package com.poly.model;

import jakarta.persistence.*;

@Entity
@Table(name = "HotelRooms")
public class HotelRoom {
    @Id
    private String roomId;
    private String roomType;
    private int maxCapacity;
    private double pricePerNight;
    private String amenities;
    private String status;

    @ManyToOne
    @JoinColumn(name = "hotel_id")
    private Hotel hotel;

    // Constructors
    public HotelRoom() {}

    public HotelRoom(String roomId, String roomType, int maxCapacity, double pricePerNight, String amenities, String status, Hotel hotel) {
        this.roomId = roomId;
        this.roomType = roomType;
        this.maxCapacity = maxCapacity;
        this.pricePerNight = pricePerNight;
        this.amenities = amenities;
        this.status = status;
        this.hotel = hotel;
    }

    // Getters and Setters
    public String getRoomId() { return roomId; }
    public void setRoomId(String roomId) { this.roomId = roomId; }

    public String getRoomType() { return roomType; }
    public void setRoomType(String roomType) { this.roomType = roomType; }

    public int getMaxCapacity() { return maxCapacity; }
    public void setMaxCapacity(int maxCapacity) { this.maxCapacity = maxCapacity; }

    public double getPricePerNight() { return pricePerNight; }
    public void setPricePerNight(double pricePerNight) { this.pricePerNight = pricePerNight; }

    public String getAmenities() { return amenities; }
    public void setAmenities(String amenities) { this.amenities = amenities; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Hotel getHotel() { return hotel; }
    public void setHotel(Hotel hotel) { this.hotel = hotel; }
}
