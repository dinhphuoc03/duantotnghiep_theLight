package com.poly.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "Hotels")
public class Hotel {
    @Id
    private String hotelId;
    private String hotelName;
    private String location;
    private int starRating;
    private String description;
    private String amenities;
    private String imageUrl;
    private String contactInfo;
    private String status;

    @ManyToOne
    @JoinColumn(name = "provider_id")
    private ServiceProvider serviceProvider;

    @OneToMany(mappedBy = "hotel", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<HotelRoom> hotelRooms;

    // Constructors
    public Hotel() {}
    
    public Hotel(String hotelId, String hotelName, String location, int starRating, String description, String amenities,
                 String imageUrl, String contactInfo, String status, ServiceProvider serviceProvider) {
        this.hotelId = hotelId;
        this.hotelName = hotelName;
        this.location = location;
        this.starRating = starRating;
        this.description = description;
        this.amenities = amenities;
        this.imageUrl = imageUrl;
        this.contactInfo = contactInfo;
        this.status = status;
        this.serviceProvider = serviceProvider;
    }

    // Getters and Setters
    public String getHotelId() { return hotelId; }
    public void setHotelId(String hotelId) { this.hotelId = hotelId; }

    public String getHotelName() { return hotelName; }
    public void setHotelName(String hotelName) { this.hotelName = hotelName; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public int getStarRating() { return starRating; }
    public void setStarRating(int starRating) { this.starRating = starRating; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getAmenities() { return amenities; }
    public void setAmenities(String amenities) { this.amenities = amenities; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public String getContactInfo() { return contactInfo; }
    public void setContactInfo(String contactInfo) { this.contactInfo = contactInfo; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public ServiceProvider getServiceProvider() { return serviceProvider; }
    public void setServiceProvider(ServiceProvider serviceProvider) { this.serviceProvider = serviceProvider; }

    public List<HotelRoom> getHotelRooms() { return hotelRooms; }
    public void setHotelRooms(List<HotelRoom> hotelRooms) { this.hotelRooms = hotelRooms; }
}
