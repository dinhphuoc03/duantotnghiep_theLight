package com.poly.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "ServiceRatings")
public class ServiceRating {

    @Id
    @Column(name = "rating_id", length = 10)
    private String ratingId;

    @Column(name = "service_id", nullable = false, length = 10)
    private String serviceId;

    @Column(name = "rating", nullable = false)
    private Integer rating;

    @Column(name = "review", length = 500)
    private String review;

    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    // Constructors
    public ServiceRating() {}

    public ServiceRating(String ratingId, String serviceId, Integer rating, String review, Customer customer) {
        this.ratingId = ratingId;
        this.serviceId = serviceId;
        this.rating = rating;
        this.review = review;
        this.customer = customer;
    }

    // Getters and Setters
    public String getRatingId() {
        return ratingId;
    }

    public void setRatingId(String ratingId) {
        this.ratingId = ratingId;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
