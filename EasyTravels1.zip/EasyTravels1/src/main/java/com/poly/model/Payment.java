package com.poly.model;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "Payments")
public class Payment {
    @Id
    private String paymentId;
    private String bookingId;
    private String bookingType;
    private double amountPaid;
    private String paymentMethod;
    private String paymentStatus;

    @Temporal(TemporalType.TIMESTAMP)
    private Date paymentDate;

    // Constructors
    public Payment() {}

    public Payment(String paymentId, String bookingId, String bookingType, double amountPaid, String paymentMethod,
                   String paymentStatus, Date paymentDate) {
        this.paymentId = paymentId;
        this.bookingId = bookingId;
        this.bookingType = bookingType;
        this.amountPaid = amountPaid;
        this.paymentMethod = paymentMethod;
        this.paymentStatus = paymentStatus;
        this.paymentDate = paymentDate;
    }

    // Getters and Setters
    public String getPaymentId() { return paymentId; }
    public void setPaymentId(String paymentId) { this.paymentId = paymentId; }

    public String getBookingId() { return bookingId; }
    public void setBookingId(String bookingId) { this.bookingId = bookingId; }

    public String getBookingType() { return bookingType; }
    public void setBookingType(String bookingType) { this.bookingType = bookingType; }

    public double getAmountPaid() { return amountPaid; }
    public void setAmountPaid(double amountPaid) { this.amountPaid = amountPaid; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }

    public Date getPaymentDate() { return paymentDate; }
    public void setPaymentDate(Date paymentDate) { this.paymentDate = paymentDate; }
}
