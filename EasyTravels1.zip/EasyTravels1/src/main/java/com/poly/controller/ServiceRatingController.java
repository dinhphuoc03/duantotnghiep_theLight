package com.poly.controller;

import com.poly.model.ServiceRating;
import com.poly.service.ServiceRatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ratings")
public class ServiceRatingController {

    @Autowired
    private ServiceRatingService serviceRatingService;

    @PostMapping
    public ResponseEntity<ServiceRating> createRating(@RequestBody ServiceRating serviceRating) {
        return ResponseEntity.ok(serviceRatingService.save(serviceRating));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ServiceRating> getRatingById(@PathVariable String id) {
        return ResponseEntity.ok(serviceRatingService.findById(id));
    }

    @GetMapping
    public ResponseEntity<List<ServiceRating>> getAllRatings() {
        return ResponseEntity.ok(serviceRatingService.findAll());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRating(@PathVariable String id) {
        serviceRatingService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
