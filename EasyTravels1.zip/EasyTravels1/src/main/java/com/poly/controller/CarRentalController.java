package com.poly.controller;

import com.poly.model.CarRental;
import com.poly.service.CarRentalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cars")
public class CarRentalController {

    @Autowired
    private CarRentalService carRentalService;

    @PostMapping
    public ResponseEntity<CarRental> createCar(@RequestBody CarRental carRental) {
        return ResponseEntity.ok(carRentalService.save(carRental));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CarRental> getCarById(@PathVariable String id) {
        return ResponseEntity.ok(carRentalService.findById(id));
    }

    @GetMapping
    public ResponseEntity<List<CarRental>> getAllCars() {
        return ResponseEntity.ok(carRentalService.findAll());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCar(@PathVariable String id) {
        carRentalService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
