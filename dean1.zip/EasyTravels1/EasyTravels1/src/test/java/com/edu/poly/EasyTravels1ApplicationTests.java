package com.edu.poly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EasyTravels1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
