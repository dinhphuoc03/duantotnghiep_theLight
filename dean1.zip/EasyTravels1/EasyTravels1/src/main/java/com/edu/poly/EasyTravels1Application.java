package com.edu.poly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EasyTravels1Application {

	public static void main(String[] args) {
		SpringApplication.run(EasyTravels1Application.class, args);
	}

}
