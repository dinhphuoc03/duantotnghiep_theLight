package com.poly.repository;

import com.poly.model.ServiceRating;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ServiceRatingRepository extends JpaRepository<ServiceRating, String> {
    
    // Tìm tất cả đánh giá theo khách hàng
    List<ServiceRating> findByCustomerId(String customerId);
    
    // Tìm tất cả đánh giá theo ID dịch vụ
    List<ServiceRating> findByServiceId(String serviceId);
}
