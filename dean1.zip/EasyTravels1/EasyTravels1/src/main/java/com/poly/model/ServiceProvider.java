package com.poly.model;


import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "ServiceProviders")
public class ServiceProvider {

    @Id
    @Column(name = "provider_id", length = 10)
    private String providerId;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "address", length = 255)
    private String address;

    @Column(name = "phone", length = 15)
    private String phone;

    @ManyToOne
    @JoinColumn(name = "account_id")
    private Account account;

    @OneToMany(mappedBy = "serviceProvider", cascade = CascadeType.ALL)
    private Set<ServiceRating> serviceRatings = new HashSet<>();

    // Constructors
    public ServiceProvider() {}

    public ServiceProvider(String providerId, String name, String address, String phone, Account account) {
        this.providerId = providerId;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.account = account;
    }

    // Getters and Setters
    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public Set<ServiceRating> getServiceRatings() {
        return serviceRatings;
    }

    public void setServiceRatings(Set<ServiceRating> serviceRatings) {
        this.serviceRatings = serviceRatings;
    }
}
