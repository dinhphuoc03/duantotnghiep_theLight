package com.poly.service;

import com.poly.model.Tour;
import java.util.List;

public interface TourService {
    Tour save(Tour tour);
    Tour findById(String id);
    List<Tour> findAll();
    void delete(String id);
}
