package com.poly.service.impl;

import com.poly.model.Tour;
import com.poly.repository.TourRepository;
import com.poly.service.TourService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TourServiceImpl implements TourService {

    @Autowired
    private TourRepository tourRepository;

    @Override
    public Tour save(Tour tour) {
        return tourRepository.save(tour);
    }

    @Override
    public Tour findById(String id) {
        return tourRepository.findById(id).orElse(null);
    }

    @Override
    public List<Tour> findAll() {
        return tourRepository.findAll();
    }

    @Override
    public void delete(String id) {
        tourRepository.deleteById(id);
    }
}
