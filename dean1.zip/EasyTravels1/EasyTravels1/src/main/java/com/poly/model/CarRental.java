package com.poly.model;

import jakarta.persistence.*;

@Entity
@Table(name = "CarRentals")
public class CarRental {
    @Id
    private String carId;
    private String carModel;
    private String carType;
    private double pricePerDay;
    private int capacity;
    private String description;
    private String imageUrl;
    private String status;

    @ManyToOne
    @JoinColumn(name = "provider_id")
    private ServiceProvider serviceProvider;

    // Constructors
    public CarRental() {}

    public CarRental(String carId, String carModel, String carType, double pricePerDay, int capacity, String description,
                     String imageUrl, String status, ServiceProvider serviceProvider) {
        this.carId = carId;
        this.carModel = carModel;
        this.carType = carType;
        this.pricePerDay = pricePerDay;
        this.capacity = capacity;
        this.description = description;
        this.imageUrl = imageUrl;
        this.status = status;
        this.serviceProvider = serviceProvider;
    }

    // Getters and Setters
    public String getCarId() { return carId; }
    public void setCarId(String carId) { this.carId = carId; }

    public String getCarModel() { return carModel; }
    public void setCarModel(String carModel) { this.carModel = carModel; }

    public String getCarType() { return carType; }
    public void setCarType(String carType) { this.carType = carType; }

    public double getPricePerDay() { return pricePerDay; }
    public void setPricePerDay(double pricePerDay) { this.pricePerDay = pricePerDay; }

    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public ServiceProvider getServiceProvider() { return serviceProvider; }
    public void setServiceProvider(ServiceProvider serviceProvider) { this.serviceProvider = serviceProvider; }
}
