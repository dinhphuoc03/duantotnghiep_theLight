package com.poly.repository;

import com.poly.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, String> {
    
    // Tìm tất cả thanh toán theo booking_id
    List<Payment> findByBookingId(String bookingId);
}