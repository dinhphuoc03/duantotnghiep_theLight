package com.poly.controller;

import com.poly.model.ServiceProvider;
import com.poly.service.ServiceProviderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/providers")
public class ServiceProviderController {

    @Autowired
    private ServiceProviderService serviceProviderService;

    @PostMapping
    public ResponseEntity<ServiceProvider> createProvider(@RequestBody ServiceProvider serviceProvider) {
        return ResponseEntity.ok(serviceProviderService.save(serviceProvider));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ServiceProvider> getProviderById(@PathVariable String id) {
        return ResponseEntity.ok(serviceProviderService.findById(id));
    }

    @GetMapping
    public ResponseEntity<List<ServiceProvider>> getAllProviders() {
        return ResponseEntity.ok(serviceProviderService.findAll());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProvider(@PathVariable String id) {
        serviceProviderService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
