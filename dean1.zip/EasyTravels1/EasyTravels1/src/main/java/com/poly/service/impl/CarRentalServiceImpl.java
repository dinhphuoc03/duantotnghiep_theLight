package com.poly.service.impl;

import com.poly.model.CarRental;
import com.poly.repository.CarRentalRepository;
import com.poly.service.CarRentalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarRentalServiceImpl implements CarRentalService {

    @Autowired
    private CarRentalRepository carRentalRepository;

    @Override
    public CarRental save(CarRental carRental) {
        return carRentalRepository.save(carRental);
    }

    @Override
    public CarRental findById(String id) {
        return carRentalRepository.findById(id).orElse(null);
    }

    @Override
    public List<CarRental> findAll() {
        return carRentalRepository.findAll();
    }

    @Override
    public void delete(String id) {
        carRentalRepository.deleteById(id);
    }
}
