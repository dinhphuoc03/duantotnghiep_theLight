package com.poly.repository;

import com.poly.model.TourBooking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TourBookingRepository extends JpaRepository<TourBooking, String> {
    
    // Tìm tất cả đặt tour theo khách hàng
    List<TourBooking> findByCustomerId(String customerId);
}
