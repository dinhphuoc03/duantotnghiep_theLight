package com.poly.service;

import com.poly.model.CarRental;
import java.util.List;

public interface CarRentalService {
    CarRental save(CarRental carRental);
    CarRental findById(String id);
    List<CarRental> findAll();
    void delete(String id);
}
