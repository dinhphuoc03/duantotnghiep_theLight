package com.poly.service.impl;

import com.poly.model.Hotel;
import com.poly.repository.HotelRepository;
import com.poly.service.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HotelServiceImpl implements HotelService {

    @Autowired
    private HotelRepository hotelRepository;

    @Override
    public Hotel save(Hotel hotel) {
        return hotelRepository.save(hotel);
    }

    @Override
    public Hotel findById(String id) {
        return hotelRepository.findById(id).orElse(null);
    }

    @Override
    public List<Hotel> findAll() {
        return hotelRepository.findAll();
    }

    @Override
    public void delete(String id) {
        hotelRepository.deleteById(id);
    }
}
