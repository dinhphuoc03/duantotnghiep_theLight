package com.poly.service;

import com.poly.model.Customer;
import java.util.List;

public interface CustomerService {
    Customer save(Customer customer);
    Customer findById(String id);
    List<Customer> findAll();
    void delete(String id);
}
