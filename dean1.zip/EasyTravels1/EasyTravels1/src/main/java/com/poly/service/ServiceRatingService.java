package com.poly.service;

import com.poly.model.ServiceRating;
import java.util.List;

public interface ServiceRatingService {
    ServiceRating save(ServiceRating serviceRating);
    ServiceRating findById(String id);
    List<ServiceRating> findAll();
    void delete(String id);
}
