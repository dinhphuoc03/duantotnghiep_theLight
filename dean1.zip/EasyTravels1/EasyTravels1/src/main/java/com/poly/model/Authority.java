package com.poly.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Authorities")
public class Authority<Account> {

    @Id
    @Column(name = "authority_id", length = 10)
    private String authorityId;

    @Column(name = "authority_name", nullable = false, length = 50)
    private String authorityName;

    @ManyToOne
    @JoinColumn(name = "account_id", nullable = false)
    private Account account;

    // Constructors
    public Authority() {}

    public Authority(String authorityId, String authorityName, Account account) {
        this.authorityId = authorityId;
        this.authorityName = authorityName;
        this.account = account;
    }

    // Getters and Setters
    public String getAuthorityId() {
        return authorityId;
    }

    public void setAuthorityId(String authorityId) {
        this.authorityId = authorityId;
    }

    public String getAuthorityName() {
        return authorityName;
    }

    public void setAuthorityName(String authorityName) {
        this.authorityName = authorityName;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }
}
