package com.poly.repository;

import com.poly.model.CarRental;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CarRentalRepository extends JpaRepository<CarRental, String> {
    
    // Tìm tất cả xe theo nhà cung cấp
    List<CarRental> findByProviderId(String providerId);
    
    // Tìm xe theo mẫu xe
    List<CarRental> findByCarModelContaining(String carModel);
}
