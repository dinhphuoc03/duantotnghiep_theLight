package com.poly.model;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "Revenues")
public class Revenue {
    @Id
    private String revenueId;
    private String serviceId;
    private String serviceType;
    private double totalRevenue;

    @Temporal(TemporalType.TIMESTAMP)
    private Date revenueDate;

    @ManyToOne
    @JoinColumn(name = "provider_id")
    private ServiceProvider serviceProvider;

    // Constructors
    public Revenue() {}

    public Revenue(String revenueId, String serviceId, String serviceType, double totalRevenue, Date revenueDate, ServiceProvider serviceProvider) {
        this.revenueId = revenueId;
        this.serviceId = serviceId;
        this.serviceType = serviceType;
        this.totalRevenue = totalRevenue;
        this.revenueDate = revenueDate;
        this.serviceProvider = serviceProvider;
    }

    // Getters and Setters
    public String getRevenueId() { return revenueId; }
    public void setRevenueId(String revenueId) { this.revenueId = revenueId; }

    public String getServiceId() { return serviceId; }
    public void setServiceId(String serviceId) { this.serviceId = serviceId; }

    public String getServiceType() { return serviceType; }
    public void setServiceType(String serviceType) { this.serviceType = serviceType; }

    public double getTotalRevenue() { return totalRevenue; }
    public void setTotalRevenue(double totalRevenue) { this.totalRevenue = totalRevenue; }

    public Date getRevenueDate() { return revenueDate; }
    public void setRevenueDate(Date revenueDate) { this.revenueDate = revenueDate; }

    public ServiceProvider getServiceProvider() { return serviceProvider; }
    public void setServiceProvider(ServiceProvider serviceProvider) { this.serviceProvider = serviceProvider; }
}
