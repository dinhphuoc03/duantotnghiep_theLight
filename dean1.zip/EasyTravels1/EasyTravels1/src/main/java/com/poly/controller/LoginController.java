package com.poly.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.poly.service.impl.AccountServiceImpl;


@Controller
public class LoginController {
    
    @Autowired
    private AccountServiceImpl accountServiceImpl;

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, RedirectAttributes redirectAttributes) {
        boolean isValidUser = accountServiceImpl.login(username, password);
        
        if (isValidUser) {
            String role = accountServiceImpl.getRole(username);
            if ("Admin".equals(role)) {
                return "redirect:/Admin/TrangChu";  // Điều hướng đến trang Admin nếu là Admin
            } else if ("Customer".equals(role)) {
                return "redirect:/User/HomePage";  // Điều hướng đến trang Customer
            } else if ("ServiceProvider".equals(role)) {
                return "redirect:/Partner/HomePage";  // Điều hướng đến trang Service Provider
            }
        } else {
        	redirectAttributes.addFlashAttribute("error", "Invalid username or password.");
            return "redirect:/Login.html";  // Trả về trang đăng nhập nếu thất bại
        }
		return password;
    }
}
