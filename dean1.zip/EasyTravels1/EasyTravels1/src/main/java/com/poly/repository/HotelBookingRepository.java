package com.poly.repository;

import com.poly.model.HotelBooking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HotelBookingRepository extends JpaRepository<HotelBooking, String> {
    
    // Tìm tất cả đặt phòng theo khách hàng
    List<HotelBooking> findByCustomerId(String customerId);
}
