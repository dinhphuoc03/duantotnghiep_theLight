package com.poly.model;
import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "Customers")
public class Customer {

    @Id
    @Column(name = "customer_id", length = 10)
    private String customerId;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "email", nullable = false, unique = true, length = 100)
    private String email;

    @Column(name = "phone", length = 15)
    private String phone;

    @Column(name = "address", length = 255)
    private String address;

    @ManyToOne
    @JoinColumn(name = "account_id")
    private Account account;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    private Set<HotelBooking> hotelBookings = new HashSet<>();

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    private Set<CarBooking> carBookings = new HashSet<>();

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    private Set<TourBooking> tourBookings = new HashSet<>();

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    private Set<ServiceRating> serviceRatings = new HashSet<>();

    // Constructors, Getters, Setters
    public Customer() {}

    public Customer(String customerId, String name, String email, String phone, String address, Account account) {
        this.customerId = customerId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.account = account;
    }

    // Getters and Setters
    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public Set<HotelBooking> getHotelBookings() {
        return hotelBookings;
    }

    public void setHotelBookings(Set<HotelBooking> hotelBookings) {
        this.hotelBookings = hotelBookings;
    }

    public Set<CarBooking> getCarBookings() {
        return carBookings;
    }

    public void setCarBookings(Set<CarBooking> carBookings) {
        this.carBookings = carBookings;
    }

    public Set<TourBooking> getTourBookings() {
        return tourBookings;
    }

    public void setTourBookings(Set<TourBooking> tourBookings) {
        this.tourBookings = tourBookings;
    }

    public Set<ServiceRating> getServiceRatings() {
        return serviceRatings;
    }

    public void setServiceRatings(Set<ServiceRating> serviceRatings) {
        this.serviceRatings = serviceRatings;
    }
}
