package com.poly.repository;

import com.poly.model.Authority;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuthorityRepository extends JpaRepository<Authority, String> {
    
    // Tìm quyền hạn theo account_id
    List<Authority> findByAccountId(String accountId);
}
