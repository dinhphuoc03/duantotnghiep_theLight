package com.poly.service.impl;

import com.poly.model.Account;
import com.poly.repository.AccountRepository;
import com.poly.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AccountServiceImpl implements AccountService {
    
    @Autowired
    private AccountRepository accountRepository;
    @Override
    public boolean login(String username, String password) {
        Optional<Account> accountOptional = accountRepository.findByUsername(username);
        if (accountOptional.isPresent()) {
            Account account = accountOptional.get(); // Lấy đối tượng Account ra từ Optional
            if (account.getPassword().equals(password)) {
                return true; // Đăng nhập thành công
            }
        }
        return false; // Đăng nhập thất bại
    }

    @Override
    public String getRole(String username) {
        Optional<Account> accountOptional = accountRepository.findByUsername(username);
        if (accountOptional.isPresent()) {
            Account account = accountOptional.get(); // Lấy đối tượng Account ra từ Optional
            return account.getRole(); // Trả về vai trò của người dùng
        }
        return null; // Người dùng không tồn tại
    }


    @Override
    public Account save(Account account) {
        return accountRepository.save(account);
    }

    @Override
    public Account findById(String id) {
        return accountRepository.findById(id).orElse(null);
    }

    @Override
    public List<Account> findAll() {
        return accountRepository.findAll();
    }

    @Override
    public void delete(String id) {
        accountRepository.deleteById(id);
    }
}
